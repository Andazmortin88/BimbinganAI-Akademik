import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const code = url.searchParams.get("code");
  const next = url.searchParams.get("next")?.startsWith("/") ? url.searchParams.get("next")! : "/dashboard";
  if (code) {
    const supabase = await createClient();
    const { error } = await supabase.auth.exchangeCodeForSession(code);
    if (!error) {
      const { data: profile } = await supabase.from("profiles").select("role,status").single();
      if (profile?.role === "STUDENT") {
        const { data: student } = await supabase.from("student_profiles").select("profile_id").maybeSingle();
        if (!student) return NextResponse.redirect(new URL("/register", url.origin));
        if (profile.status === "PENDING") return NextResponse.redirect(new URL("/pending", url.origin));
      }
      return NextResponse.redirect(new URL(next, url.origin));
    }
  }
  return NextResponse.redirect(new URL("/?auth_error=1", url.origin));
}

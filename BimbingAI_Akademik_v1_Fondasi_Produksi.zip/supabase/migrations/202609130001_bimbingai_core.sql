-- BimbingAI Akademik: schema inti, RLS, dan storage privat.
create extension if not exists pgcrypto;
create schema if not exists private;

create type public.app_role as enum ('ADMIN','LECTURER','STUDENT');
create type public.account_status as enum ('PENDING','ACTIVE','REJECTED','DISABLED','COMPLETED');
create type public.program_code as enum ('S1','D3','NERS');
create type public.work_type as enum ('SKRIPSI','KTI','KIA');
create type public.review_status as enum ('DRAFT','SUBMITTED','WAITING_REVIEW','IN_REVIEW','REVISION','FIXED','APPROVED','DONE');
create type public.decision_status as enum ('PENDING','APPROVED','REVISION','REJECTED');
create type public.comment_visibility as enum ('PUBLIC','PRIVATE');
create type public.comment_severity as enum ('MAJOR','MINOR','LANGUAGE');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete restrict,
  role public.app_role not null default 'STUDENT',
  status public.account_status not null default 'PENDING',
  full_name text not null check (char_length(full_name) between 2 and 150),
  email text not null,
  avatar_url text,
  last_seen_at timestamptz,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
  unique (email)
);
create table public.lecturer_profiles (
  profile_id uuid primary key references public.profiles(id) on delete cascade,
  nidn text unique, expertise text, phone text, is_main_supervisor boolean not null default false,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.academic_periods (
  id uuid primary key default gen_random_uuid(), name text not null unique, semester smallint not null check(semester in (1,2)),
  starts_on date not null, ends_on date not null, is_active boolean not null default false,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.student_profiles (
  profile_id uuid primary key references public.profiles(id) on delete cascade,
  nim text not null unique, whatsapp text not null, program public.program_code not null, cohort smallint not null,
  class_name text not null, work_type public.work_type not null, academic_period_id uuid references public.academic_periods(id),
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
  check ((program='S1' and work_type='SKRIPSI') or (program='D3' and work_type='KTI') or (program='NERS' and work_type='KIA'))
);
create table public.progress_stages (
  id smallint primary key check(id between 1 and 17), name text not null unique, weight numeric(6,3) not null default 1 check(weight>=0), work_type public.work_type,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.research_projects (
  id uuid primary key default gen_random_uuid(), student_id uuid not null unique references public.student_profiles(profile_id),
  title text, current_stage_id smallint not null default 1 references public.progress_stages(id), next_target_on date, defense_target_on date,
  archived_at timestamptz, archived_by uuid references public.profiles(id), created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.supervision_assignments (
  id uuid primary key default gen_random_uuid(), project_id uuid not null references public.research_projects(id), lecturer_id uuid not null references public.lecturer_profiles(profile_id),
  supervisor_number smallint not null check(supervisor_number in (1,2)), is_active boolean not null default true, assigned_by uuid references public.profiles(id),
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(), unique(project_id,supervisor_number), unique(project_id,lecturer_id)
);
create table public.progress_histories (
  id uuid primary key default gen_random_uuid(), project_id uuid not null references public.research_projects(id), from_stage_id smallint references public.progress_stages(id),
  to_stage_id smallint not null references public.progress_stages(id), note text, created_by uuid not null references public.profiles(id), created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.title_submissions (
  id uuid primary key default gen_random_uuid(), project_id uuid not null references public.research_projects(id), sequence_no smallint not null check(sequence_no between 1 and 3),
  title text not null, background text not null, research_problem text not null, objective text not null, variables_focus text,
  population text, location text, proposed_method text, initial_references text, decision public.decision_status not null default 'PENDING',
  decision_reason text, decided_by uuid references public.profiles(id), decided_at timestamptz, created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(), unique(project_id,sequence_no)
);
create table public.guidance_threads (
  id uuid primary key default gen_random_uuid(), project_id uuid not null references public.research_projects(id), subject text not null,
  status public.review_status not null default 'DRAFT', supervisor_number smallint check(supervisor_number in (1,2)), created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.guidance_sessions (
  id uuid primary key default gen_random_uuid(), thread_id uuid not null references public.guidance_threads(id), stage_id smallint references public.progress_stages(id),
  summary text, is_official boolean not null default false, officialized_by uuid references public.profiles(id), officialized_at timestamptz,
  created_by uuid not null references public.profiles(id), created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.messages (
  id uuid primary key default gen_random_uuid(), thread_id uuid not null references public.guidance_threads(id), sender_id uuid not null references public.profiles(id),
  body text not null check(char_length(body) between 1 and 20000), read_at timestamptz, deleted_at timestamptz,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.documents (
  id uuid primary key default gen_random_uuid(), project_id uuid not null references public.research_projects(id), category text not null,
  latest_version integer not null default 0 check(latest_version>=0), archived_at timestamptz, created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(), unique(project_id,category)
);
create table public.document_versions (
  id uuid primary key default gen_random_uuid(), document_id uuid not null references public.documents(id), version_no integer not null check(version_no>0),
  original_name text not null, archive_name text not null, storage_path text not null unique, mime_type text not null, size_bytes bigint not null check(size_bytes>0 and size_bytes<=52428800),
  checksum_sha256 text not null, stage_id smallint references public.progress_stages(id), previous_version_id uuid references public.document_versions(id),
  status public.review_status not null default 'SUBMITTED', uploaded_by uuid not null references public.profiles(id), extracted_text_path text,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(), unique(document_id,version_no)
);
create table public.document_comments (
  id uuid primary key default gen_random_uuid(), document_version_id uuid not null references public.document_versions(id), author_id uuid not null references public.profiles(id),
  visibility public.comment_visibility not null default 'PUBLIC', severity public.comment_severity not null default 'MINOR', page_number integer,
  section_label text, quoted_text text, comment_text text not null, status public.review_status not null default 'REVISION', resolved_at timestamptz,
  parent_id uuid references public.document_comments(id), created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.consultation_records (
  id uuid primary key default gen_random_uuid(), project_id uuid not null references public.research_projects(id), session_id uuid references public.guidance_sessions(id),
  consultation_on timestamptz not null, material text not null, feedback text, status public.review_status not null, supervisor_id uuid not null references public.lecturer_profiles(profile_id),
  created_by uuid not null references public.profiles(id), created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.appointments (
  id uuid primary key default gen_random_uuid(), project_id uuid not null references public.research_projects(id), lecturer_id uuid not null references public.lecturer_profiles(profile_id),
  starts_at timestamptz not null, method text not null check(method in ('Tatap muka','Google Meet/Zoom','WhatsApp')), topic text not null, note text,
  meeting_url text, decision public.decision_status not null default 'PENDING', attendance text check(attendance in ('HADIR','TIDAK_HADIR')),
  created_by uuid not null references public.profiles(id), created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.notifications (
  id uuid primary key default gen_random_uuid(), recipient_id uuid not null references public.profiles(id), title text not null, body text not null,
  type text not null, target_url text, read_at timestamptz, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.followup_logs (
  id uuid primary key default gen_random_uuid(), project_id uuid not null references public.research_projects(id), channel text not null default 'WHATSAPP', message text not null,
  sent_by uuid not null references public.profiles(id), sent_at timestamptz not null default now(), created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.turnitin_records (
  id uuid primary key default gen_random_uuid(), project_id uuid not null references public.research_projects(id), document_version_id uuid references public.document_versions(id),
  similarity_percentage numeric(5,2) check(similarity_percentage between 0 and 100), report_path text, recorded_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.review_rubrics (
  id uuid primary key default gen_random_uuid(), name text not null, work_type public.work_type not null, version integer not null default 1,
  criteria jsonb not null, is_active boolean not null default true, created_by uuid references public.profiles(id), created_at timestamptz not null default now(), updated_at timestamptz not null default now(), unique(name,work_type,version)
);
create table public.ai_reviews (
  id uuid primary key default gen_random_uuid(), document_version_id uuid not null references public.document_versions(id), rubric_id uuid references public.review_rubrics(id),
  review_mode text not null, document_hash text not null, model_name text not null, rubric_version integer not null, status text not null default 'PROCESSING',
  requested_by uuid not null references public.profiles(id), completed_at timestamptz, error_message text,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(), unique(document_hash,review_mode,rubric_version,model_name)
);
create table public.ai_review_items (
  id uuid primary key default gen_random_uuid(), ai_review_id uuid not null references public.ai_reviews(id), category text not null, severity public.comment_severity not null,
  location text, quotation text, finding text not null, rationale text not null, suggestion text not null, confidence numeric(4,3) check(confidence between 0 and 1), examiner_question text,
  verification_source text, selected_by_lecturer boolean not null default false, edited_text text, shared_at timestamptz,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.institution_guidelines (
  id uuid primary key default gen_random_uuid(), name text not null, work_type public.work_type, storage_path text not null, version integer not null default 1,
  is_active boolean not null default true, created_by uuid not null references public.profiles(id), created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.generated_reports (
  id uuid primary key default gen_random_uuid(), project_id uuid references public.research_projects(id), report_type text not null, storage_path text not null,
  parameters jsonb not null default '{}'::jsonb, generated_by uuid not null references public.profiles(id), created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.audit_logs (
  id bigint generated always as identity primary key, actor_id uuid references public.profiles(id), action text not null, entity_type text not null, entity_id text,
  ip_hash text, metadata jsonb not null default '{}'::jsonb, created_at timestamptz not null default now()
);

create index idx_assignments_lecturer on public.supervision_assignments(lecturer_id) where is_active;
create index idx_projects_stage on public.research_projects(current_stage_id) where archived_at is null;
create index idx_threads_project_updated on public.guidance_threads(project_id,updated_at desc);
create index idx_messages_thread_created on public.messages(thread_id,created_at);
create index idx_doc_versions_document on public.document_versions(document_id,version_no desc);
create index idx_comments_version on public.document_comments(document_version_id,status);
create index idx_notifications_unread on public.notifications(recipient_id,created_at desc) where read_at is null;
create index idx_appointments_lecturer_date on public.appointments(lecturer_id,starts_at);
create index idx_projects_search on public.research_projects using gin(to_tsvector('simple',coalesce(title,'')));
create index idx_profiles_search on public.profiles using gin(to_tsvector('simple',full_name||' '||email));

create or replace function private.set_updated_at() returns trigger language plpgsql security invoker set search_path='' as $$begin new.updated_at=now(); return new; end$$;
create or replace function private.handle_new_user() returns trigger language plpgsql security definer set search_path='' as $$
begin
  insert into public.profiles(id,role,status,full_name,email,avatar_url)
  values(new.id,'STUDENT','PENDING',coalesce(nullif(new.raw_user_meta_data->>'full_name',''),split_part(coalesce(new.email,''),'@',1)),coalesce(new.email,new.id::text||'@pending.local'),new.raw_user_meta_data->>'avatar_url')
  on conflict(id) do nothing;
  return new;
end$$;
create trigger on_auth_user_created after insert on auth.users for each row execute function private.handle_new_user();
do $$ declare t text; begin foreach t in array array['profiles','lecturer_profiles','academic_periods','student_profiles','progress_stages','research_projects','supervision_assignments','progress_histories','title_submissions','guidance_threads','guidance_sessions','messages','documents','document_versions','document_comments','consultation_records','appointments','notifications','followup_logs','turnitin_records','review_rubrics','ai_reviews','ai_review_items','institution_guidelines','generated_reports'] loop execute format('create trigger set_updated_at before update on public.%I for each row execute function private.set_updated_at()',t); end loop; end$$;

create or replace function private.is_admin() returns boolean language sql stable security definer set search_path='' as $$select (select auth.uid()) is not null and exists(select 1 from public.profiles p where p.id=(select auth.uid()) and p.role='ADMIN' and p.status='ACTIVE')$$;
create or replace function private.is_assigned(project uuid) returns boolean language sql stable security definer set search_path='' as $$select (select auth.uid()) is not null and exists(select 1 from public.supervision_assignments a join public.profiles p on p.id=a.lecturer_id where a.project_id=project and a.lecturer_id=(select auth.uid()) and a.is_active and p.status='ACTIVE')$$;
create or replace function private.owns_project(project uuid) returns boolean language sql stable security definer set search_path='' as $$select (select auth.uid()) is not null and exists(select 1 from public.research_projects r where r.id=project and r.student_id=(select auth.uid()))$$;
revoke all on all functions in schema private from public,anon,authenticated;
grant usage on schema private to authenticated;
grant execute on function private.is_admin() to authenticated;
grant execute on function private.is_assigned(uuid) to authenticated;
grant execute on function private.owns_project(uuid) to authenticated;

do $$declare t text; begin foreach t in array array['profiles','lecturer_profiles','academic_periods','student_profiles','progress_stages','research_projects','supervision_assignments','progress_histories','title_submissions','guidance_threads','guidance_sessions','messages','documents','document_versions','document_comments','consultation_records','appointments','notifications','followup_logs','turnitin_records','review_rubrics','ai_reviews','ai_review_items','institution_guidelines','generated_reports','audit_logs'] loop execute format('alter table public.%I enable row level security',t); end loop; end$$;

create policy profile_self_read on public.profiles for select to authenticated using(id=(select auth.uid()) or private.is_admin());
create policy profile_self_update on public.profiles for update to authenticated using(id=(select auth.uid())) with check(id=(select auth.uid()) and role=(select p.role from public.profiles p where p.id=(select auth.uid())));
create policy profiles_admin_all on public.profiles for all to authenticated using(private.is_admin()) with check(private.is_admin());
create policy student_self on public.student_profiles for select to authenticated using(profile_id=(select auth.uid()) or private.is_admin() or exists(select 1 from public.research_projects r where r.student_id=profile_id and private.is_assigned(r.id)));
create policy student_self_update on public.student_profiles for update to authenticated using(profile_id=(select auth.uid())) with check(profile_id=(select auth.uid()));
create policy student_self_insert on public.student_profiles for insert to authenticated with check(profile_id=(select auth.uid()));
create policy lecturer_visible on public.lecturer_profiles for select to authenticated using(true);
create policy admin_lecturer_manage on public.lecturer_profiles for all to authenticated using(private.is_admin()) with check(private.is_admin());
create policy reference_read_periods on public.academic_periods for select to authenticated using(true);
create policy reference_read_stages on public.progress_stages for select to authenticated using(true);
create policy admin_reference_periods on public.academic_periods for all to authenticated using(private.is_admin()) with check(private.is_admin());
create policy admin_reference_stages on public.progress_stages for all to authenticated using(private.is_admin()) with check(private.is_admin());
create policy projects_read on public.research_projects for select to authenticated using(student_id=(select auth.uid()) or private.is_assigned(id) or private.is_admin());
create policy projects_lecturer_update on public.research_projects for update to authenticated using(private.is_assigned(id) or private.is_admin()) with check(private.is_assigned(id) or private.is_admin());
create policy projects_student_insert on public.research_projects for insert to authenticated with check(student_id=(select auth.uid()) and created_by=(select auth.uid()));
create policy assignments_read on public.supervision_assignments for select to authenticated using(lecturer_id=(select auth.uid()) or private.owns_project(project_id) or private.is_admin());
create policy assignments_admin on public.supervision_assignments for all to authenticated using(private.is_admin()) with check(private.is_admin());

-- Tabel yang langsung memiliki project_id.
do $$declare t text; begin foreach t in array array['progress_histories','title_submissions','guidance_threads','documents','consultation_records','appointments','followup_logs','turnitin_records','generated_reports'] loop
 execute format('create policy %I on public.%I for select to authenticated using(private.owns_project(project_id) or private.is_assigned(project_id) or private.is_admin())',t||'_read',t);
 execute format('create policy %I on public.%I for insert to authenticated with check(private.owns_project(project_id) or private.is_assigned(project_id) or private.is_admin())',t||'_insert',t);
 execute format('create policy %I on public.%I for update to authenticated using(private.is_assigned(project_id) or private.is_admin()) with check(private.is_assigned(project_id) or private.is_admin())',t||'_update',t);
end loop; end$$;

create policy sessions_read on public.guidance_sessions for select to authenticated using(exists(select 1 from public.guidance_threads g where g.id=thread_id and (private.owns_project(g.project_id) or private.is_assigned(g.project_id) or private.is_admin())));
create policy sessions_write on public.guidance_sessions for insert to authenticated with check(exists(select 1 from public.guidance_threads g where g.id=thread_id and (private.owns_project(g.project_id) or private.is_assigned(g.project_id) or private.is_admin())));
create policy sessions_update_lecturer on public.guidance_sessions for update to authenticated using(exists(select 1 from public.guidance_threads g where g.id=thread_id and (private.is_assigned(g.project_id) or private.is_admin()))) with check(exists(select 1 from public.guidance_threads g where g.id=thread_id and (private.is_assigned(g.project_id) or private.is_admin())));
create policy messages_read on public.messages for select to authenticated using(exists(select 1 from public.guidance_threads g where g.id=thread_id and (private.owns_project(g.project_id) or private.is_assigned(g.project_id) or private.is_admin())));
create policy messages_insert on public.messages for insert to authenticated with check(sender_id=(select auth.uid()) and exists(select 1 from public.guidance_threads g where g.id=thread_id and (private.owns_project(g.project_id) or private.is_assigned(g.project_id) or private.is_admin())));
create policy versions_read on public.document_versions for select to authenticated using(exists(select 1 from public.documents d where d.id=document_id and (private.owns_project(d.project_id) or private.is_assigned(d.project_id) or private.is_admin())));
create policy versions_insert on public.document_versions for insert to authenticated with check(uploaded_by=(select auth.uid()) and exists(select 1 from public.documents d where d.id=document_id and (private.owns_project(d.project_id) or private.is_assigned(d.project_id) or private.is_admin())));
create policy comments_read on public.document_comments for select to authenticated using(exists(select 1 from public.document_versions v join public.documents d on d.id=v.document_id where v.id=document_version_id and (private.is_assigned(d.project_id) or private.is_admin() or (private.owns_project(d.project_id) and visibility='PUBLIC'))));
create policy comments_insert on public.document_comments for insert to authenticated with check(author_id=(select auth.uid()) and exists(select 1 from public.document_versions v join public.documents d on d.id=v.document_id where v.id=document_version_id and (private.owns_project(d.project_id) or private.is_assigned(d.project_id) or private.is_admin())) and (visibility='PUBLIC' or private.is_assigned((select d2.project_id from public.document_versions v2 join public.documents d2 on d2.id=v2.document_id where v2.id=document_version_id)) or private.is_admin()));
create policy notifications_own on public.notifications for select to authenticated using(recipient_id=(select auth.uid()));
create policy notifications_own_update on public.notifications for update to authenticated using(recipient_id=(select auth.uid())) with check(recipient_id=(select auth.uid()));
create policy rubric_lecturer_read on public.review_rubrics for select to authenticated using(private.is_admin() or exists(select 1 from public.profiles p where p.id=(select auth.uid()) and p.role='LECTURER' and p.status='ACTIVE'));
create policy rubric_admin on public.review_rubrics for all to authenticated using(private.is_admin()) with check(private.is_admin());
create policy ai_reviews_lecturer on public.ai_reviews for select to authenticated using(private.is_admin() or exists(select 1 from public.document_versions v join public.documents d on d.id=v.document_id where v.id=document_version_id and private.is_assigned(d.project_id)));
create policy ai_items_lecturer on public.ai_review_items for select to authenticated using(private.is_admin() or exists(select 1 from public.ai_reviews a join public.document_versions v on v.id=a.document_version_id join public.documents d on d.id=v.document_id where a.id=ai_review_id and private.is_assigned(d.project_id)));
create policy guidelines_read on public.institution_guidelines for select to authenticated using(true);
create policy guidelines_admin on public.institution_guidelines for all to authenticated using(private.is_admin()) with check(private.is_admin());
create policy audit_admin on public.audit_logs for select to authenticated using(private.is_admin());

insert into public.progress_stages(id,name,weight) values
(1,'Belum mengajukan judul',0),(2,'Pengajuan Judul',4),(3,'Judul Disetujui',4),(4,'BAB I',6),(5,'BAB II',6),(6,'BAB III',8),(7,'Proposal Lengkap',7),(8,'Seminar Proposal',6),(9,'Revisi Proposal',5),(10,'Ethical Clearance/Izin Penelitian',7),(11,'Pengumpulan Data',10),(12,'BAB IV',9),(13,'BAB V',9),(14,'Skripsi/KTI/KIA Lengkap',7),(15,'Sidang Akhir',5),(16,'Revisi Sidang',5),(17,'Selesai',2);

insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types) values
('guidance-documents','guidance-documents',false,52428800,array['application/pdf','application/msword','application/vnd.openxmlformats-officedocument.wordprocessingml.document','application/vnd.ms-excel','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','image/png','image/jpeg']),
('institution-guidelines','institution-guidelines',false,52428800,array['application/pdf','application/vnd.openxmlformats-officedocument.wordprocessingml.document']),
('avatars','avatars',false,5242880,array['image/png','image/jpeg']),
('reports','reports',false,52428800,array['application/pdf','application/zip']) on conflict(id) do nothing;

-- Path guidance-documents wajib: <student_uuid>/<project_uuid>/<filename>.
create policy storage_guidance_read on storage.objects for select to authenticated using(bucket_id='guidance-documents' and (private.is_admin() or (storage.foldername(name))[1]=(select auth.uid())::text or private.is_assigned(((storage.foldername(name))[2])::uuid)));
create policy storage_guidance_insert on storage.objects for insert to authenticated with check(bucket_id='guidance-documents' and ((storage.foldername(name))[1]=(select auth.uid())::text or private.is_assigned(((storage.foldername(name))[2])::uuid) or private.is_admin()));
create policy storage_avatar_read on storage.objects for select to authenticated using(bucket_id='avatars');
create policy storage_avatar_write on storage.objects for insert to authenticated with check(bucket_id='avatars' and (storage.foldername(name))[1]=(select auth.uid())::text);
create policy storage_guideline_read on storage.objects for select to authenticated using(bucket_id='institution-guidelines');
create policy storage_guideline_admin on storage.objects for insert to authenticated with check(bucket_id='institution-guidelines' and private.is_admin());
create policy storage_reports_read on storage.objects for select to authenticated using(bucket_id='reports' and (private.is_admin() or (storage.foldername(name))[1]=(select auth.uid())::text));

grant select,insert,update on all tables in schema public to authenticated;
revoke delete on all tables in schema public from authenticated;
revoke all on public.audit_logs from anon,authenticated;
grant select on public.audit_logs to authenticated;

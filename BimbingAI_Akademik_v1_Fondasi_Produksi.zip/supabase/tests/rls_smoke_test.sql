-- Jalankan pada SQL Editor setelah migration. Test ini hanya memeriksa struktur dasar.
select tablename, rowsecurity
from pg_tables
where schemaname='public' and tablename in ('profiles','research_projects','messages','document_comments','ai_reviews')
order by tablename;

select id,name,weight from public.progress_stages order by id;

select id,public,file_size_limit from storage.buckets
where id in ('guidance-documents','institution-guidelines','avatars','reports')
order by id;


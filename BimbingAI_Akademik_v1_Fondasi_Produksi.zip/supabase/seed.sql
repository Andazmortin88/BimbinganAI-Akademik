-- Jalankan hanya pada project development. Jangan jalankan di production.
insert into public.academic_periods(name,semester,starts_on,ends_on,is_active)
values ('Ganjil 2026/2027',1,'2026-08-01','2027-01-31',true)
on conflict(name) do nothing;

insert into public.review_rubrics(name,work_type,version,criteria)
values
('Review Skripsi Keperawatan','SKRIPSI',1,'[{"code":"gap","label":"Research gap dan novelty"},{"code":"method","label":"Konsistensi metode"},{"code":"statistics","label":"Analisis dan interpretasi statistik"}]'),
('Review KTI Keperawatan','KTI',1,'[{"code":"problem","label":"Ketepatan masalah"},{"code":"method","label":"Kesesuaian metode"},{"code":"discussion","label":"Kedalaman pembahasan"}]'),
('Review KIA Profesi Ners','KIA',1,'[{"code":"assessment","label":"Pengkajian"},{"code":"sdki","label":"Diagnosis SDKI"},{"code":"slki_siki","label":"SLKI dan SIKI"},{"code":"ebn","label":"Evidence-based nursing"}]')
on conflict(name,work_type,version) do nothing;

